//
//  ViewController.swift
//  Stack View
//
//  Created by MAC on 30/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var horizontalView: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let  btn = UIButton()
        btn.frame = CGRect(x: 0, y: 0, width: 100, height: 50)
        btn.backgroundColor = UIColor.blue
        btn.setTitle("btn", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        view.addSubview(btn)
        
        let  btn2 = UIButton()
        btn2.frame = CGRect(x: 0, y: 0, width: 100, height: 50)
        btn2.backgroundColor = UIColor.orange
        btn2.setTitle("btn2", for: .normal)
        btn2.setTitleColor(.white, for: .normal)
        view.addSubview(btn2)
        
        let  btn3 = UIButton()
        btn3.frame = CGRect(x: 0, y: 0, width: 100, height: 50)
        btn3.backgroundColor = UIColor.black
        btn3.setTitle("btn3", for: .normal)
        btn3.setTitleColor(.white, for: .normal)
        view.addSubview(btn3)
        
        let  btn4 = UIButton()
        btn4.frame = CGRect(x: 0, y: 0, width: 100, height: 50)
        btn4.backgroundColor = UIColor.green
        btn4.setTitle("btn4", for: .normal)
        btn4.setTitleColor(.white, for: .normal)
        view.addSubview(btn4)
        
        var verticalView = UIStackView(arrangedSubviews: [btn, btn2, btn3])
        verticalView.frame = CGRect(x: 10, y: 560, width: self.view.frame.size.width-20, height: 100)
//        verticalView.insertArrangedSubview(btn4, at: 1)
        verticalView.addArrangedSubview(btn4)
//        verticalView.removeArrangedSubview(btn)
//        verticalView.isBaselineRelativeArrangement = false
//        verticalView.isLayoutMarginsRelativeArrangement = false
        verticalView.axis = .vertical
        verticalView.distribution = .fillEqually
        verticalView.alignment = .fill
//        verticalView.setCustomSpacing(10, after: btn3)
        verticalView.spacing = 10
        
        view.addSubview(verticalView)
        // Do any additional setup after loading the view.
    }


}

